library(testthat)
library(FNMLE)

test_check("FNMLE")